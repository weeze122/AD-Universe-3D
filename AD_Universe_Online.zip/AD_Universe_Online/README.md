# A&D Universe — Online Edition

A playable 2D browser game with an explorable city, basketball arena, football field, real-time WebSocket rooms, player movement, chat, and synchronized scores. **This is not GTA/2K/Madden-quality 3D realism.** It's a custom indie multiplayer browser game foundation.

## Run on your PC

1. Install Node.js 18 or newer from https://nodejs.org/.
2. Extract this ZIP and open a terminal inside `AD_Universe_Online`.
3. Run `npm install` and then `npm start`.
4. Open `http://localhost:3000` in your browser.
5. Open another tab to test multiplayer. To connect from another computer on the same Wi-Fi, visit `http://YOUR-PC-LAN-IP:3000` if firewall rules allow it.

## Put it online for friends

**Option A — Render (one service):**
1. Sign up at https://github.com and make a new repository for this project.
2. Upload `server.js`, `package.json`, `public/index.html`, and this README, keeping the same folder structure. Do not upload `node_modules`.
3. Go to https://render.com, create a new **Web Service** and connect the GitHub repository.
4. Select **Node**, with Build Command `npm install` and Start Command `npm start`.
5. Deploy, then use the public `https://YOUR-SERVICE.onrender.com` URL.
6. Give friends the URL and a matching room code. Keep the same room to see each other.

Free hosting tiers can sleep, have rate limits, or change; inspect the provider's latest pricing and terms before deployment. A static-only host such as Netlify Drop cannot host this WebSocket server by uploading the ZIP alone.

## Features / controls

- City: WASD / arrow keys to move, Shift to sprint, E near the blue or green venue to enter.
- Sports: click, Space, or mobile ACTION button to shoot/attempt scoring.
- Basketball: points are based on distance, shot has variable accuracy.
- Football: reach right end-zone (x > 1080) and press Space/ACTION for a touchdown.
- Press ESC or CITY to return to city.
- Online multiplayer: room code and server-authoritative scoring; typed chat; players sync positions across clients.
- Mobile: movement arrows and ACTION button.

## Important limitations / next development milestones

- 2D top-down; not lifelike 3D, no driving, basketball teams, football teams, ball ownership, matchmaking, or account persistence yet.
- Server currently accepts room changes and modes without enforcing a location gate. Basic anti-spam and movement checks are present, but production security would require authoritative movement, proper account moderation, and rate limiting.
- Room names are not secret passwords; don't share sensitive info in chat. No long-term accounts or saves are collected.
- Scores reset on reconnect; keep a room's players under ~16 for this prototype.
- Music and external imagery intentionally omitted; the artwork is drawn with HTML Canvas.

Built for A&D Studios.
